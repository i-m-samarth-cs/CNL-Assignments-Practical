/*A5: Write a program to demonstrate subnetting and find the subnet masks. */

import java.util.Scanner;
import java.net.InetAddress;

class Subnet{
public static void main(String args[])
  {
	Scanner sc = new Scanner(System.in);
	System.out.print("\n Enter the ip address: ");
	String ip = sc.nextLine();
	String split_ip[] = ip.split("\\.");//SPlit the string after every.
	String split_bip[] = new String[422]; //split binary ip
	String bip = "";
	for(int i=0;i<4;i++)
	{
// "18" => 18 => 10010 => 00010010
		split_bip[i] = appendZeros(Integer.toBinaryString(Integer.parseInt(split_ip[i]))); 
		bip += split_bip[i];
	}	
	System.out.println("\n IP in binary is "+bip);
	System.out.print("\n Enter the number of sub-networks: ");
	int n = sc.nextInt();

//Calculation of mask   
/*eg if address = 120, log 120/log 2 gives log to the base 2 => 6.9068, ceil gives us upper integer */
	int bits = (int)Math.ceil(Math.log(n)/Math.log(2)); 

	System.out.println("\n Number of bits required for sub-network addressing = "+bits);

    int[] arr=new int[32]; //arr[] is mask after subnetting
    for(int i=0;i<32;i++)     {     arr[i]=1;     }

    int cc = Integer.parseInt(split_ip[0]); //class check
    String mask = null;
    int x =0;
	if(cc>0 && cc<224)
        {
            if(cc<128)
            {       
			mask = "255.0.0.0";
              	x = 8+bits;
			System.out.println("\n Class= A");
            }
            if(cc>127 && cc<192)
            {
                mask = "255.255.0.0";
                 x = 16+bits; 
			System.out.println("\n Class= B");               
            }
            if(cc>191)
            {
                mask = "255.255.255.0";
                 x = 24+bits;
			System.out.println("\n Class= C");                
            }
		for(int i=x;i<32;i++)
                {
                   arr[i]=0;
                }            
        }
	System.out.println("\n The default subnet mask is = "+mask);
	System.out.println("\n Subnet mask bits = "+x);
	System.out.println("\n The subnet mask is = ");
        for(int i=0;i<32;i++)
        {
        	System.out.print(arr[i]);
        }
	System.out.println("\n");
 }//main() ends

static String appendZeros(String s)
 {
	String temp = new String("00000000");
	return temp.substring(s.length())+ s;
 }

}

/* //OUTPUT

C:\Program Files (x86)\Java\jdk1.6.0\bin>javac Subnet.java

C:\Program Files (x86)\Java\jdk1.6.0\bin>java Subnet

 Enter the ip address: 1.2.3.4

 IP in binary is 00000001000000100000001100000100

 Enter the number of sub-networks: 6

 Number of bits required for sub-network addressing = 3

 Class= A

 The default subnet mask is = 255.0.0.0

 Subnet mask bits = 11

 The subnet mask is =
11111111111000000000000000000000


C:\Program Files (x86)\Java\jdk1.6.0\bin>
*/


